select word from Words
order by lower(word)