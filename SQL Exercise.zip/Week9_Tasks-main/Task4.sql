select word from Words
where word like '%i%'