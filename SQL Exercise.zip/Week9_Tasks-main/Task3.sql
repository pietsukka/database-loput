select Word
from Words
order by Word
offset 1 rows