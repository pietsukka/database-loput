select min(Word) as word
from Words;