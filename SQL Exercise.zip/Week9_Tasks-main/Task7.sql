select word from Words
where word like '%a%a%' and word not like '%a%a%a%'