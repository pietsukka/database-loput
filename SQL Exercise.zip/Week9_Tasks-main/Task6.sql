select word from Words
where word like '_p___'