select sum(len(concat(FirstName, ' ', LastName))) as TotalLength
from Customers;
