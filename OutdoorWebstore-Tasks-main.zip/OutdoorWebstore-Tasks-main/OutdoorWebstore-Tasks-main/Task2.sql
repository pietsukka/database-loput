select ProductName, len(ProductName) as NameLength
from Products