select ProductName
from Products
order by len(ProductName), ProductName