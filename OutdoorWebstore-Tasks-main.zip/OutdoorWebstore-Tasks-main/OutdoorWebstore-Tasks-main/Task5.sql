select concat(FirstName, ' ', LastName) as FullName
from Customers;
