select *
from Orders
where OrderDate >= '2023-10-03' and OrderDate <= '2024-01-31';
