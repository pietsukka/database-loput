select ProductName, Price*2 as PriceDoubled
from Products
